# 🪨📄✂️ Rock Paper Scissors — DSA Visualization Platform

A premium, glassmorphism/neon-themed **Rock Paper Scissors** game built as a
**Data Structures & Algorithms (DSA)** academic project. It plays like a
game but teaches like a lecture — every click visually demonstrates a real
data-structure operation (Array push/shift, Stack push/pop, Queue
enqueue/dequeue, random number generation, and time/space complexity).

Built with **plain HTML5, CSS3 and vanilla JavaScript** — no frameworks,
no build step, no npm install required.

---

## 📁 Folder Structure

```
rps-dsa-project/
├── index.html          # All page markup/sections
├── css/
│   └── style.css       # Full glassmorphism + neon theme, animations, responsive rules
├── js/
│   └── main.js         # Game logic + all DSA visualizations (modular, commented)
├── assets/              # (empty — reserved for any images/icons you add)
└── README.md            # This file
```

---

## ✨ Features Implemented

- Animated landing intro (logo → title → game slides up)
- Glassmorphism neon-cyber UI (Electric Blue / Purple / Cyan palette)
- Full gameplay: countdown, handshake animation, win/lose/tie states,
  confetti on win, screen shake on loss, click/hover/win/lose sound effects
  (generated with the Web Audio API — no audio files needed)
- **Array visualization** — `history[]` with animated `push()` and the
  sliding-window `shift()` once it exceeds 10 items
- **Stack visualization** — Undo button demonstrates `push()` / `pop()` (LIFO)
- **Queue visualization** — last 5 moves shown as `enqueue()` / `dequeue()` (FIFO)
- **Random Number Generator panel** — live `Math.floor(Math.random()*3)` demo
- **Algorithm panel** — step-by-step walkthrough, auto-highlighted each round
- **Flowchart** and **syntax-highlighted pseudocode** with hover tooltips
  explaining `push`, `shift`, and `Math.random`
- **Time & Space Complexity** cards (O(1) vs O(n) operations)
- **Statistics dashboard** — win rate ring, streaks, bar charts
- **DSA "What's happening internally?" side panel** — live operation trace
- Export match history as downloadable JSON
- Dark/Light mode toggle + 4 bonus color themes (Cyber, Ocean, Sunset, Space)
- Fully responsive (desktop, tablet, mobile) + keyboard accessible

---

## 🚀 How to Run in VS Code (Step-by-Step)

### Option A — Live Server extension (recommended, auto-reload)

1. **Unzip** the project folder and open it in VS Code:
   `File → Open Folder… → select "rps-dsa-project"`
2. Install the **Live Server** extension by *Ritwick Dey*:
   - Click the Extensions icon in the left sidebar (or `Ctrl+Shift+X` /
     `Cmd+Shift+X`)
   - Search **"Live Server"**
   - Click **Install**
3. In the VS Code file explorer, **right-click `index.html`** →
   **"Open with Live Server"**.
4. Your default browser opens automatically at something like
   `http://127.0.0.1:5500/index.html` — the game is now running, and the
   page will auto-refresh whenever you edit a file.

### Option B — No extension, just open the file

1. Unzip the project.
2. Double-click `index.html` (or right-click → *Open with* → your browser).
3. It will run directly — sound effects, animations and all DSA logic work
   fully offline since everything is vanilla JS with no external APIs.

> Note: Option A is preferred because some browsers restrict certain
> features (like `Blob` downloads or audio autoplay policies) more
> strictly on `file://` pages than on a local server.

### Option C — Node's built-in static server (if you have Node.js installed)

```bash
cd rps-dsa-project
npx serve .
```
Then open the printed local URL (usually `http://localhost:3000`).

---

## 🎓 Using This for a Viva / Demonstration

Suggested walkthrough order:

1. Play a few rounds — point out the **Array Visualization** section
   updating live with `push()`.
2. Play until more than 10 rounds are logged — show the **shift()**
   animation (sliding window / FIFO overflow handling).
3. Click **Undo** — show the **Stack** (`push`/`pop`, LIFO) reverting score.
4. Point out the **Queue** section — last 5 moves (FIFO, `enqueue`/`dequeue`).
5. Open the **⚡ DSA trace panel** (bottom-right button) to show every
   operation logged in real time with its complexity.
6. Scroll to **Random Number Generator**, **Algorithm Panel**,
   **Flowchart**, **Pseudocode**, and **Time/Space Complexity** sections to
   explain the theory behind the implementation.
7. Show the **Statistics Dashboard** and **Export JSON** button as a
   demonstration of derived/aggregated data.

---

## ✏️ Customizing

- **Student name**: edit the placeholder text inside
  `<span class="student-name" id="student-name-display">` in `index.html`.
- **GitHub link**: update the `href="#"` on `#github-btn` in `index.html`.
- **Colors/theme**: all colors are CSS variables at the top of
  `css/style.css` under `:root`.
- **History/Queue size limits**: change `HISTORY_MAX` and `QUEUE_MAX` in
  `js/main.js`.

---

## 🧠 Tech Stack

- HTML5 (semantic sections, ARIA labels)
- CSS3 (custom properties, glassmorphism, keyframe animations, grid/flex,
  media queries)
- JavaScript ES6+ (modular functions, no frameworks, no dependencies)

Enjoy the game — and good luck with your DSA project! 🚀
