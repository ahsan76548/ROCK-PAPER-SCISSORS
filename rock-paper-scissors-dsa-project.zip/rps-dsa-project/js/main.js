/* =========================================================================
   ROCK PAPER SCISSORS — DSA VISUALIZATION PLATFORM
   main.js
   Vanilla JavaScript — modular, well-commented, no frameworks.
   ========================================================================= */

'use strict';

/* =========================================================================
   1. GLOBAL STATE
   -------------------------------------------------------------------------
   Everything the game needs lives in one state object. This keeps the
   data model easy to reason about and easy to reset.
   ========================================================================= */
const MOVES = ['rock', 'paper', 'scissors'];
const MOVE_EMOJI = { rock: '🪨', paper: '📄', scissors: '✂️' };
const HISTORY_MAX = 10;   // Array capacity -> sliding window
const QUEUE_MAX = 5;      // Queue capacity

const state = {
  playerScore: 0,
  computerScore: 0,
  history: [],        // ARRAY: full move log, capped at HISTORY_MAX (push/shift)
  undoStack: [],       // STACK: LIFO log of rounds for Undo (push/pop)
  moveQueue: [],        // QUEUE: FIFO of last N moves (enqueue/dequeue)
  stats: {
    played: 0, wins: 0, losses: 0, draws: 0,
    currentWinStreak: 0, currentLoseStreak: 0,
    longestWinStreak: 0, longestLoseStreak: 0
  },
  soundOn: true,
  isRoundInProgress: false
};

/* =========================================================================
   2. DOM REFERENCES
   ========================================================================= */
const el = (id) => document.getElementById(id);

const dom = {
  introOverlay: el('intro-overlay'),
  themeToggle: el('theme-toggle'),
  soundToggle: el('sound-toggle'),
  choiceButtons: document.querySelectorAll('.choice-btn'),
  countdownDisplay: el('countdown-display'),
  countdownNumber: el('countdown-number'),
  handshake: el('handshake-anim'),
  roundResultText: el('round-result-text'),
  playerMoveIcon: el('player-move-icon'),
  computerMoveIcon: el('computer-move-icon'),
  playerMoveDisplay: el('player-move-display'),
  computerMoveDisplay: el('computer-move-display'),
  playerScoreEl: el('player-score'),
  computerScoreEl: el('computer-score'),
  playerCard: document.querySelector('.player-card'),
  computerCard: document.querySelector('.computer-card'),
  playerMiniHistory: el('player-mini-history'),
  computerMiniHistory: el('computer-mini-history'),
  computerAvatar: el('computer-avatar'),
  undoBtn: el('undo-btn'),
  resetBtn: el('reset-btn'),

  arrayIndexRow: el('array-index-row'),
  arrayValueRow: el('array-value-row'),
  arrayEmptyMsg: el('array-empty-msg'),

  stackBlocks: el('stack-blocks'),
  queueBlocks: el('queue-blocks'),

  randomMovesArray: el('random-moves-array'),
  randomResult: el('random-result'),

  algoSteps: document.querySelectorAll('.algo-step'),

  statPlayed: el('stat-played'),
  statWins: el('stat-wins'),
  statLosses: el('stat-losses'),
  statDraws: el('stat-draws'),
  statStreakWin: el('stat-streak-win'),
  statStreakLose: el('stat-streak-lose'),
  winrateRingFg: el('winrate-ring-fg'),
  winrateNumber: el('winrate-number'),
  barWin: el('bar-win'),
  barLose: el('bar-lose'),
  barDraw: el('bar-draw'),
  exportJsonBtn: el('export-json-btn'),

  themeOptions: el('theme-options'),

  eduPanel: el('dsa-edu-panel'),
  eduPanelBody: el('edu-panel-body'),
  eduPanelToggle: el('edu-panel-toggle'),
  eduPanelClose: el('edu-panel-close'),

  modalOverlay: el('result-modal'),
  modalIcon: el('modal-icon'),
  modalTitle: el('modal-title'),
  modalSub: el('modal-sub'),
  modalPlayerScore: el('modal-player-score'),
  modalComputerScore: el('modal-computer-score'),
  modalPlayAgain: el('modal-play-again'),
  modalReset: el('modal-reset'),

  codeTooltip: el('code-tooltip'),
  toast: el('toast')
};

/* =========================================================================
   3. INTRO ANIMATION — remove overlay from DOM flow after it fades out
   ========================================================================= */
setTimeout(() => {
  dom.introOverlay.style.display = 'none';
}, 4300);

/* =========================================================================
   4. PARTICLE BACKGROUND (Canvas)
   ========================================================================= */
(function particleBackground() {
  const canvas = el('particle-canvas');
  const ctx = canvas.getContext('2d');
  let particles = [];
  let mouse = { x: null, y: null };

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  function colorFromCSS(varName) {
    return getComputedStyle(document.body).getPropertyValue(varName).trim();
  }

  function createParticles() {
    const count = Math.min(70, Math.floor((canvas.width * canvas.height) / 22000));
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 2 + 0.6,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      alpha: Math.random() * 0.6 + 0.2
    }));
  }
  createParticles();
  window.addEventListener('resize', createParticles);

  window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  });

  function tick() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const accent = colorFromCSS('--accent') || '#22d3ee';

    particles.forEach((p) => {
      // gentle drift
      p.x += p.vx;
      p.y += p.vy;

      // mouse parallax attraction
      if (mouse.x !== null) {
        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 140) {
          p.x -= dx * 0.004;
          p.y -= dy * 0.004;
        }
      }

      if (p.x < 0) p.x = canvas.width;
      if (p.x > canvas.width) p.x = 0;
      if (p.y < 0) p.y = canvas.height;
      if (p.y > canvas.height) p.y = 0;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = accent;
      ctx.globalAlpha = p.alpha;
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    requestAnimationFrame(tick);
  }
  tick();
})();

/* =========================================================================
   5. SOUND ENGINE (Web Audio API — no external audio files needed)
   ========================================================================= */
const SoundEngine = (function () {
  let audioCtx = null;
  function ctx() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
  }
  function beep({ freq = 440, duration = 0.12, type = 'sine', gain = 0.08, glideTo = null }) {
    if (!state.soundOn) return;
    const c = ctx();
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, c.currentTime);
    if (glideTo) osc.frequency.linearRampToValueAtTime(glideTo, c.currentTime + duration);
    g.gain.setValueAtTime(gain, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + duration);
    osc.connect(g).connect(c.destination);
    osc.start();
    osc.stop(c.currentTime + duration);
  }
  return {
    click: () => beep({ freq: 320, duration: 0.08, type: 'square', gain: 0.05 }),
    hover: () => beep({ freq: 700, duration: 0.05, type: 'sine', gain: 0.02 }),
    countdown: () => beep({ freq: 500, duration: 0.09, type: 'triangle', gain: 0.06 }),
    win: () => beep({ freq: 440, duration: 0.4, type: 'sine', gain: 0.09, glideTo: 880 }),
    lose: () => beep({ freq: 300, duration: 0.4, type: 'sawtooth', gain: 0.08, glideTo: 120 }),
    tie: () => beep({ freq: 500, duration: 0.25, type: 'sine', gain: 0.06, glideTo: 500 })
  };
})();

dom.soundToggle.addEventListener('click', () => {
  state.soundOn = !state.soundOn;
  dom.soundToggle.textContent = state.soundOn ? '🔊' : '🔇';
});

/* =========================================================================
   6. THEME (Dark/Light) + THEME SWITCHER (Cyber/Ocean/Sunset/Space)
   ========================================================================= */
dom.themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('light-mode');
  dom.themeToggle.textContent = document.body.classList.contains('light-mode') ? '☀️' : '🌙';
});

dom.themeOptions.addEventListener('click', (e) => {
  const chip = e.target.closest('.theme-chip');
  if (!chip) return;
  document.querySelectorAll('.theme-chip').forEach((c) => c.classList.remove('active'));
  chip.classList.add('active');
  const theme = chip.dataset.theme;
  if (theme === 'cyber') {
    document.body.removeAttribute('data-theme');
  } else {
    document.body.setAttribute('data-theme', theme);
  }
});

/* =========================================================================
   7. DSA EDUCATION PANEL — helper to append a "trace" card
   ========================================================================= */
function eduTrace(opTitle, flowLines, complexity) {
  const card = document.createElement('div');
  card.className = 'edu-trace';
  card.innerHTML = `
    <div class="trace-op">${opTitle}</div>
    <div class="trace-flow">${flowLines.map((l) => `<span>↓ ${l}</span>`).join('')}</div>
    <span class="trace-complexity">${complexity}</span>
  `;
  // clear the placeholder text the first time something is traced
  const placeholder = dom.eduPanelBody.querySelector('.edu-placeholder');
  if (placeholder) placeholder.remove();
  dom.eduPanelBody.prepend(card);
  // cap the number of visible trace cards to keep the panel light
  const cards = dom.eduPanelBody.querySelectorAll('.edu-trace');
  if (cards.length > 12) cards[cards.length - 1].remove();
}

dom.eduPanelToggle.addEventListener('click', () => dom.eduPanel.classList.add('open'));
dom.eduPanelClose.addEventListener('click', () => dom.eduPanel.classList.remove('open'));

/* =========================================================================
   8. ARRAY VISUALIZATION (history[])
   -------------------------------------------------------------------------
   Renders index row + value row. push() and shift() are visually animated.
   ========================================================================= */
function renderArray({ justInserted = false, justRemoved = false } = {}) {
  dom.arrayIndexRow.innerHTML = '';
  dom.arrayValueRow.innerHTML = '';

  if (state.history.length === 0) {
    dom.arrayValueRow.appendChild(dom.arrayEmptyMsg);
    return;
  }

  state.history.forEach((move, i) => {
    const idxCell = document.createElement('div');
    idxCell.className = 'array-cell-index';
    idxCell.textContent = i;
    dom.arrayIndexRow.appendChild(idxCell);

    const valCell = document.createElement('div');
    valCell.className = 'array-cell';
    valCell.textContent = MOVE_EMOJI[move];
    // animate only the most recently inserted element
    if (justInserted && i === state.history.length - 1) {
      valCell.classList.add('inserting');
    }
    dom.arrayValueRow.appendChild(valCell);
  });
}

/**
 * Pushes a move into the bounded history array (a "sliding window").
 * Demonstrates: push() -> O(1) amortized, shift() -> O(n) when overflow.
 */
function pushToHistory(move) {
  state.history.push(move); // O(1) amortized
  renderArray({ justInserted: true });
  eduTrace('history.push(move)', ['Array length increased', 'Element inserted at end', 'Memory updated'], 'O(1) amortized');

  if (state.history.length > HISTORY_MAX) {
    // Sliding window: drop oldest element to keep the array bounded
    state.history.shift(); // O(n) — every remaining item re-indexes
    renderArray({ justRemoved: true });
    eduTrace('history.shift()', ['Oldest element removed', 'All remaining items re-indexed', 'Sliding window maintained'], 'O(n)');
  }
}

/* =========================================================================
   9. STACK VISUALIZATION (undoStack) — Undo feature
   ========================================================================= */
function renderStack() {
  dom.stackBlocks.innerHTML = '';
  if (state.undoStack.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'stack-empty';
    empty.textContent = 'Stack is empty — play a round to push a frame.';
    dom.stackBlocks.appendChild(empty);
    return;
  }
  state.undoStack.forEach((round, i) => {
    const block = document.createElement('div');
    block.className = 'stack-block';
    block.textContent = `#${i + 1} — You: ${MOVE_EMOJI[round.player]}  Bot: ${MOVE_EMOJI[round.computer]}  (${round.result})`;
    dom.stackBlocks.appendChild(block);
  });
}

function pushToUndoStack(round) {
  state.undoStack.push(round); // O(1)
  renderStack();
  eduTrace('undoStack.push(round)', ['Round frame pushed onto stack', 'Stack size increased'], 'O(1) — LIFO');
}

function popUndoStack() {
  if (state.undoStack.length === 0) {
    showToast('Nothing to undo yet.');
    return;
  }
  const blocks = dom.stackBlocks.querySelectorAll('.stack-block');
  const lastBlock = blocks[blocks.length - 1];
  const round = state.undoStack.pop(); // O(1)

  // revert score
  if (round.result === 'win') state.playerScore = Math.max(0, state.playerScore - 1);
  if (round.result === 'lose') state.computerScore = Math.max(0, state.computerScore - 1);

  // revert stats (best-effort, keeps demo consistent)
  state.stats.played = Math.max(0, state.stats.played - 1);
  if (round.result === 'win') state.stats.wins = Math.max(0, state.stats.wins - 1);
  if (round.result === 'lose') state.stats.losses = Math.max(0, state.stats.losses - 1);
  if (round.result === 'tie') state.stats.draws = Math.max(0, state.stats.draws - 1);

  updateScoreDisplays();
  updateStatsDisplay();

  const finish = () => renderStack();
  if (lastBlock) {
    lastBlock.classList.add('popping');
    setTimeout(finish, 300);
  } else {
    finish();
  }
  eduTrace('undoStack.pop()', ['Top frame removed', 'Score reverted', 'Stack size decreased'], 'O(1) — LIFO');
  showToast('Last round undone.');
  SoundEngine.click();
}

dom.undoBtn.addEventListener('click', popUndoStack);

/* =========================================================================
   10. QUEUE VISUALIZATION (moveQueue) — last N moves, FIFO
   ========================================================================= */
function renderQueue() {
  dom.queueBlocks.innerHTML = '';
  if (state.moveQueue.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'stack-empty';
    empty.textContent = 'Queue is empty.';
    dom.queueBlocks.appendChild(empty);
    return;
  }
  state.moveQueue.forEach((move) => {
    const block = document.createElement('div');
    block.className = 'queue-block';
    block.textContent = MOVE_EMOJI[move];
    dom.queueBlocks.appendChild(block);
  });
}

function enqueueMove(move) {
  state.moveQueue.push(move); // enqueue at rear -> O(1)
  eduTrace('queue.enqueue(move)', ['Move added at rear'], 'O(1) — FIFO');
  if (state.moveQueue.length > QUEUE_MAX) {
    state.moveQueue.shift(); // dequeue from front -> O(n) for arrays
    eduTrace('queue.dequeue()', ['Front element removed'], 'O(n) — array-backed');
  }
  renderQueue();
}

/* =========================================================================
   11. RANDOM NUMBER VISUALIZATION
   ========================================================================= */
function animateRandomChoice(finalIndex) {
  const cells = dom.randomMovesArray.querySelectorAll('.rand-cell');
  let ticks = 0;
  const maxTicks = 10;
  return new Promise((resolve) => {
    const interval = setInterval(() => {
      cells.forEach((c) => c.classList.remove('highlighted'));
      const randomFlicker = Math.floor(Math.random() * 3);
      cells[randomFlicker].classList.add('highlighted');
      dom.randomResult.textContent = randomFlicker;
      ticks++;
      if (ticks >= maxTicks) {
        clearInterval(interval);
        cells.forEach((c) => c.classList.remove('highlighted'));
        cells[finalIndex].classList.add('highlighted');
        dom.randomResult.textContent = `${finalIndex} → ${MOVE_EMOJI[MOVES[finalIndex]]} ${MOVES[finalIndex]}`;
        resolve();
      }
    }, 60);
  });
}

/* =========================================================================
   12. ALGORITHM STEP HIGHLIGHTING
   ========================================================================= */
async function highlightAlgoSteps() {
  for (const step of dom.algoSteps) {
    step.classList.add('active');
    await wait(180);
    step.classList.remove('active');
  }
}
function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

/* =========================================================================
   13. STATISTICS DASHBOARD
   ========================================================================= */
function updateStatsDisplay() {
  const s = state.stats;
  dom.statPlayed.textContent = s.played;
  dom.statWins.textContent = s.wins;
  dom.statLosses.textContent = s.losses;
  dom.statDraws.textContent = s.draws;
  dom.statStreakWin.textContent = s.longestWinStreak;
  dom.statStreakLose.textContent = s.longestLoseStreak;

  const winRate = s.played > 0 ? Math.round((s.wins / s.played) * 100) : 0;
  dom.winrateNumber.textContent = `${winRate}%`;
  const circumference = 326.7;
  dom.winrateRingFg.style.strokeDashoffset = String(circumference - (circumference * winRate) / 100);

  const total = s.played || 1;
  dom.barWin.style.width = `${(s.wins / total) * 100}%`;
  dom.barLose.style.width = `${(s.losses / total) * 100}%`;
  dom.barDraw.style.width = `${(s.draws / total) * 100}%`;
}

function updateScoreDisplays() {
  animateCountUp(dom.playerScoreEl, state.playerScore);
  animateCountUp(dom.computerScoreEl, state.computerScore);
}

function animateCountUp(elm, target) {
  elm.textContent = target; // simple, reliable increment display
}

/* =========================================================================
   14. MINI HISTORY CHIPS (per-player, last few moves)
   ========================================================================= */
function addMiniChip(container, move) {
  const chip = document.createElement('div');
  chip.className = 'mini-chip';
  chip.textContent = MOVE_EMOJI[move];
  container.appendChild(chip);
  while (container.children.length > 8) {
    container.removeChild(container.firstChild);
  }
}

/* =========================================================================
   15. CONFETTI + SCREEN SHAKE
   ========================================================================= */
function launchConfetti() {
  const colors = ['#3b82f6', '#8b5cf6', '#22d3ee', '#10b981'];
  for (let i = 0; i < 60; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.left = `${Math.random() * 100}vw`;
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDuration = `${1.2 + Math.random() * 1.4}s`;
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    document.body.appendChild(piece);
    setTimeout(() => piece.remove(), 2800);
  }
}

function screenShake() {
  document.body.classList.add('shake-screen');
  setTimeout(() => document.body.classList.remove('shake-screen'), 420);
}

/* =========================================================================
   16. TOAST + CODE TOOLTIP
   ========================================================================= */
let toastTimer = null;
function showToast(msg) {
  dom.toast.textContent = msg;
  dom.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => dom.toast.classList.remove('show'), 1800);
}

const CODE_EXPLANATIONS = {
  push: 'Adds an element at the end of the array. O(1) amortized.',
  shift: 'Removes the first element and re-indexes the rest. O(n).',
  random: 'Math.random() generates a pseudo-random float between 0 and 1.'
};

document.addEventListener('mousemove', (e) => {
  dom.codeTooltip.style.left = `${e.clientX + 14}px`;
  dom.codeTooltip.style.top = `${e.clientY + 14}px`;
});

function attachCodeTooltips() {
  const codeBlock = el('pseudocode-block');
  if (!codeBlock) return;
  const html = codeBlock.innerHTML
    .replace(/history\.push/g, '<span class="hoverable" data-exp="push">history.push</span>')
    .replace(/history\.shift/g, '<span class="hoverable" data-exp="shift">history.shift</span>')
    .replace(/Math\.random/g, '<span class="hoverable" data-exp="random">Math.random</span>');
  codeBlock.innerHTML = html;

  codeBlock.querySelectorAll('.hoverable').forEach((node) => {
    node.addEventListener('mouseenter', () => {
      const key = node.dataset.exp;
      dom.codeTooltip.textContent = CODE_EXPLANATIONS[key];
      dom.codeTooltip.classList.add('show');
    });
    node.addEventListener('mouseleave', () => dom.codeTooltip.classList.remove('show'));
  });
}
attachCodeTooltips();

/* =========================================================================
   17. RESULT MODAL
   ========================================================================= */
function openModal(result, playerMove, computerMove) {
  const icons = { win: '🏆', lose: '💥', tie: '🤝' };
  const titles = { win: 'You Win!', lose: 'Computer Wins', tie: "It's a Tie" };
  const reasonMap = {
    'rock-scissors': 'Rock crushes Scissors',
    'scissors-paper': 'Scissors cut Paper',
    'paper-rock': 'Paper covers Rock',
    'scissors-rock': 'Rock crushes Scissors',
    'paper-scissors': 'Scissors cut Paper',
    'rock-paper': 'Paper covers Rock'
  };
  dom.modalIcon.textContent = icons[result];
  dom.modalTitle.textContent = titles[result];
  dom.modalSub.textContent = result === 'tie'
    ? `Both chose ${playerMove}`
    : (reasonMap[`${playerMove}-${computerMove}`] || reasonMap[`${computerMove}-${playerMove}`] || '');
  dom.modalPlayerScore.textContent = state.playerScore;
  dom.modalComputerScore.textContent = state.computerScore;
  dom.modalOverlay.classList.add('show');
}
function closeModal() { dom.modalOverlay.classList.remove('show'); }
dom.modalPlayAgain.addEventListener('click', closeModal);
dom.modalReset.addEventListener('click', () => { closeModal(); resetEverything(); });
dom.modalOverlay.addEventListener('click', (e) => { if (e.target === dom.modalOverlay) closeModal(); });

/* =========================================================================
   18. CORE GAME LOOP
   ========================================================================= */
function decideWinner(player, computer) {
  if (player === computer) return 'tie';
  const beats = { rock: 'scissors', paper: 'rock', scissors: 'paper' };
  return beats[player] === computer ? 'win' : 'lose';
}

async function playRound(playerMove) {
  if (state.isRoundInProgress) return;
  state.isRoundInProgress = true;
  dom.choiceButtons.forEach((b) => b.classList.add('disabled'));

  SoundEngine.click();

  // --- Step 1: show player's move ---
  dom.playerMoveIcon.textContent = MOVE_EMOJI[playerMove];
  dom.playerMoveDisplay.classList.add('pop');
  addMiniChip(dom.playerMiniHistory, playerMove);
  setTimeout(() => dom.playerMoveDisplay.classList.remove('pop'), 400);

  // --- Step 2: store move inside array (DSA visualization) ---
  pushToHistory(playerMove);
  enqueueMove(playerMove);

  // --- Step 3: countdown ---
  dom.countdownDisplay.classList.add('counting');
  const seq = ['3', '2', '1', 'GO!'];
  for (const n of seq) {
    dom.countdownNumber.textContent = n;
    SoundEngine.countdown();
    await wait(340);
  }
  dom.countdownDisplay.classList.remove('counting');
  dom.countdownNumber.textContent = 'VS';

  // --- Step 4: computer "thinking" + random index generation ---
  dom.computerAvatar.classList.add('thinking');
  const randomIndex = Math.floor(Math.random() * 3);
  await animateRandomChoice(randomIndex);
  const computerMove = MOVES[randomIndex];
  dom.computerAvatar.classList.remove('thinking');

  // handshake animation
  dom.handshake.classList.add('show');
  await wait(500);
  dom.handshake.classList.remove('show');

  // reveal computer move
  dom.computerMoveIcon.textContent = MOVE_EMOJI[computerMove];
  dom.computerMoveDisplay.classList.add('pop');
  addMiniChip(dom.computerMiniHistory, computerMove);
  setTimeout(() => dom.computerMoveDisplay.classList.remove('pop'), 400);

  // --- Step 5: compare + step 6: update score ---
  const result = decideWinner(playerMove, computerMove);
  applyResult(result);

  // --- Step 7: push round to the undo stack ---
  pushToUndoStack({ player: playerMove, computer: computerMove, result });

  // algorithm step walk-through + random panel already animated above
  highlightAlgoSteps();

  // UI feedback
  dom.roundResultText.className = 'round-result ' + result;
  dom.roundResultText.textContent =
    result === 'win' ? 'You Win This Round! 🎉' :
    result === 'lose' ? 'Computer Wins This Round 💥' :
    "It's a Tie 🤝";

  dom.playerCard.classList.remove('winner', 'loser');
  dom.computerCard.classList.remove('winner', 'loser');
  if (result === 'win') {
    dom.playerCard.classList.add('winner');
    dom.computerCard.classList.add('loser');
    SoundEngine.win();
    launchConfetti();
  } else if (result === 'lose') {
    dom.computerCard.classList.add('winner');
    dom.playerCard.classList.add('loser');
    SoundEngine.lose();
    screenShake();
  } else {
    SoundEngine.tie();
  }

  openModal(result, playerMove, computerMove);

  dom.choiceButtons.forEach((b) => b.classList.remove('disabled'));
  state.isRoundInProgress = false;
}

function applyResult(result) {
  state.stats.played += 1;
  if (result === 'win') {
    state.playerScore += 1;
    state.stats.wins += 1;
    state.stats.currentWinStreak += 1;
    state.stats.currentLoseStreak = 0;
    state.stats.longestWinStreak = Math.max(state.stats.longestWinStreak, state.stats.currentWinStreak);
  } else if (result === 'lose') {
    state.computerScore += 1;
    state.stats.losses += 1;
    state.stats.currentLoseStreak += 1;
    state.stats.currentWinStreak = 0;
    state.stats.longestLoseStreak = Math.max(state.stats.longestLoseStreak, state.stats.currentLoseStreak);
  } else {
    state.stats.draws += 1;
    state.stats.currentWinStreak = 0;
    state.stats.currentLoseStreak = 0;
  }
  updateScoreDisplays();
  updateStatsDisplay();
}

/* =========================================================================
   19. BUTTON EVENTS (choices, ripple, sound)
   ========================================================================= */
dom.choiceButtons.forEach((btn) => {
  btn.addEventListener('mouseenter', () => SoundEngine.hover());
  btn.addEventListener('click', () => {
    btn.classList.add('ripple');
    setTimeout(() => btn.classList.remove('ripple'), 600);
    playRound(btn.dataset.move);
  });
});

/* =========================================================================
   20. RESET
   ========================================================================= */
function resetEverything() {
  state.playerScore = 0;
  state.computerScore = 0;
  state.history = [];
  state.undoStack = [];
  state.moveQueue = [];
  state.stats = {
    played: 0, wins: 0, losses: 0, draws: 0,
    currentWinStreak: 0, currentLoseStreak: 0,
    longestWinStreak: 0, longestLoseStreak: 0
  };

  updateScoreDisplays();
  updateStatsDisplay();
  renderArray();
  renderStack();
  renderQueue();

  dom.playerMoveIcon.textContent = '❔';
  dom.computerMoveIcon.textContent = '❔';
  dom.roundResultText.className = 'round-result';
  dom.roundResultText.textContent = 'Choose your move to begin';
  dom.playerMiniHistory.innerHTML = '';
  dom.computerMiniHistory.innerHTML = '';
  dom.playerCard.classList.remove('winner', 'loser');
  dom.computerCard.classList.remove('winner', 'loser');
  dom.eduPanelBody.innerHTML = '<p class="edu-placeholder">Play a round to see live DSA operations traced here — pushes, shifts, random index generation, and complexity notes.</p>';

  showToast('Everything has been reset.');
}
dom.resetBtn.addEventListener('click', () => {
  if (confirm('Reset scores, arrays, stack, queue and stats?')) resetEverything();
});

/* =========================================================================
   21. EXPORT MATCH HISTORY AS JSON
   ========================================================================= */
dom.exportJsonBtn.addEventListener('click', () => {
  const payload = {
    exportedAt: new Date().toISOString(),
    playerScore: state.playerScore,
    computerScore: state.computerScore,
    historyArray: state.history,
    stats: state.stats
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'rps-match-history.json';
  a.click();
  URL.revokeObjectURL(url);
  showToast('Match history exported.');
});

/* =========================================================================
   22. INITIAL RENDER
   ========================================================================= */
renderArray();
renderStack();
renderQueue();
updateStatsDisplay();
